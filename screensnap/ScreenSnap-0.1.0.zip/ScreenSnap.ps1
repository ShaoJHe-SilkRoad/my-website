# ScreenSnap 0.1.0 - a floating lens button for screen capture.
# Click or press Alt+C: capture every monitor and put the image on the clipboard.
# Drag: move the lens. Right-click: menu / exit.

# Only one copy at a time (a second one could not own Alt+C anyway).
$created = $false
$mutex = New-Object System.Threading.Mutex($true, 'Local\ScreenSnap', [ref]$created)
if (-not $created) { exit }

Add-Type -ReferencedAssemblies System.Windows.Forms, System.Drawing -TypeDefinition @"
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class SnapButton : Form
{
    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr hWnd, int id, uint mods, uint vk);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr hWnd, int id);
    [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr hWnd);
    [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
    [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr hDC);
    [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr hdc);
    [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
    [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr obj);
    [DllImport("user32.dll")] static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref POINT pptDst,
        ref SIZE psize, IntPtr hdcSrc, ref POINT pprSrc, int crKey, ref BLENDFUNCTION pblend, int dwFlags);

    [StructLayout(LayoutKind.Sequential)] struct POINT { public int X, Y; public POINT(int x, int y) { X = x; Y = y; } }
    [StructLayout(LayoutKind.Sequential)] struct SIZE { public int W, H; public SIZE(int w, int h) { W = w; H = h; } }
    [StructLayout(LayoutKind.Sequential, Pack = 1)] struct BLENDFUNCTION { public byte Op, Flags, Alpha, Format; }

    const int WS_EX_LAYERED = 0x80000, WS_EX_TOOLWINDOW = 0x80, WS_EX_TOPMOST = 0x8, WS_EX_NOACTIVATE = 0x8000000;
    const int WM_HOTKEY = 0x312, HOTKEY_ID = 1;
    const uint MOD_ALT = 0x1, MOD_NOREPEAT = 0x4000, VK_C = 0x43;

    const string CheckGlyph = "", ErrorGlyph = "";
    static readonly Color OkColor = Color.FromArgb(34, 150, 70), FailColor = Color.FromArgb(205, 45, 40);

    // Lens radius in 96-dpi units; scaled for the display.
    const float LensR = 30f;

    readonly float scale;
    readonly int pad;
    readonly string iconFont;
    readonly Timer anim = new Timer();
    readonly Timer captureDelay = new Timer();
    readonly ToolTip tip = new ToolTip();

    float hover, hoverTarget, flash;
    bool flashOk;
    DateTime flashHoldUntil;
    bool pressed, dragging, hidden, busy, hotkeyOk;
    Point downCursor, downLocation;

    public static void Run()
    {
        // Without this, scaled displays (125%, 150%...) are captured at the wrong size.
        SetProcessDPIAware();
        Application.EnableVisualStyles();
        Application.Run(new SnapButton());
    }

    public SnapButton()
    {
        using (Graphics g = Graphics.FromHwnd(IntPtr.Zero)) scale = g.DpiX / 96f;
        pad = (int)Math.Round(12 * scale);

        using (Font probe = new Font("Segoe Fluent Icons", 12f))
            iconFont = probe.Name == "Segoe Fluent Icons" ? "Segoe Fluent Icons" : "Segoe MDL2 Assets";

        FormBorderStyle = FormBorderStyle.None;
        AutoScaleMode = AutoScaleMode.None;
        ShowInTaskbar = false;
        TopMost = true;
        StartPosition = FormStartPosition.Manual;
        Cursor = Cursors.Hand;
        int size = (int)Math.Ceiling(LensR * 2 * scale) + pad * 2;
        Size = new Size(size, size);
        Rectangle work = Screen.PrimaryScreen.WorkingArea;
        Location = new Point(work.Right - size - (int)(16 * scale), work.Top + (int)(150 * scale));

        anim.Interval = 15;
        anim.Tick += OnAnimate;
        captureDelay.Interval = 150;
        captureDelay.Tick += OnCapture;

        ContextMenuStrip menu = new ContextMenuStrip();
        ToolStripMenuItem snap = new ToolStripMenuItem("Take screenshot", null, delegate { Snap(); });
        snap.ShortcutKeyDisplayString = "Alt+C";
        menu.Items.Add(snap);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(new ToolStripMenuItem("Exit", null, delegate { Close(); }));
        ContextMenuStrip = menu;
    }

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ExStyle |= WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_TOPMOST | WS_EX_NOACTIVATE;
            return cp;
        }
    }

    // Clicking the lens never steals focus, so Ctrl+V works right away in the app you were using.
    protected override bool ShowWithoutActivation { get { return true; } }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        hotkeyOk = RegisterHotKey(Handle, HOTKEY_ID, MOD_ALT | MOD_NOREPEAT, VK_C);
        tip.SetToolTip(this, hotkeyOk
            ? "Click or Alt+C: copy screenshot\nDrag: move   Right-click: menu"
            : "Click: copy screenshot (Alt+C is taken by another app)\nDrag: move   Right-click: menu");
        Render();
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        if (hotkeyOk) UnregisterHotKey(Handle, HOTKEY_ID);
        base.OnFormClosed(e);
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID) Snap();
        base.WndProc(ref m);
    }

    void Snap()
    {
        if (busy) return;
        busy = true;
        // Hide the lens so it is not in the picture.
        hidden = true;
        Render();
        captureDelay.Start();
    }

    void OnCapture(object sender, EventArgs e)
    {
        captureDelay.Stop();
        bool ok;
        try
        {
            Rectangle b = SystemInformation.VirtualScreen;
            using (Bitmap bmp = new Bitmap(b.Width, b.Height, PixelFormat.Format32bppArgb))
            {
                using (Graphics g = Graphics.FromImage(bmp))
                    g.CopyFromScreen(b.Location, Point.Empty, b.Size);
                // Retries in case another app is holding the clipboard.
                Clipboard.SetDataObject(bmp, true, 5, 100);
            }
            ok = true;
        }
        catch { ok = false; }

        hidden = false;
        flash = 1f;
        flashOk = ok;
        flashHoldUntil = DateTime.Now.AddMilliseconds(500);
        busy = false;
        anim.Start();
    }

    void OnAnimate(object sender, EventArgs e)
    {
        bool active = false;
        float d = hoverTarget - hover;
        if (Math.Abs(d) > 0.01f) { hover += d * 0.2f; active = true; }
        else hover = hoverTarget;
        if (flash > 0f)
        {
            if (DateTime.Now >= flashHoldUntil) flash = Math.Max(0f, flash - 0.04f);
            active = true;
        }
        Render();
        if (!active) anim.Stop();
    }

    protected override void OnMouseEnter(EventArgs e) { hoverTarget = 1f; anim.Start(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { hoverTarget = 0f; anim.Start(); base.OnMouseLeave(e); }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            pressed = true;
            dragging = false;
            downCursor = Cursor.Position;
            downLocation = Location;
            Render();
        }
        base.OnMouseDown(e);
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        if (pressed)
        {
            Point p = Cursor.Position;
            int dx = p.X - downCursor.X, dy = p.Y - downCursor.Y;
            // Treat movement over a few pixels as a drag, not a click.
            if (!dragging && Math.Abs(dx) + Math.Abs(dy) > 4) { dragging = true; Render(); }
            if (dragging) Location = new Point(downLocation.X + dx, downLocation.Y + dy);
        }
        base.OnMouseMove(e);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left && pressed)
        {
            pressed = false;
            if (!dragging) Snap();
            dragging = false;
            Render();
        }
        base.OnMouseUp(e);
    }

    void Render()
    {
        if (!IsHandleCreated) return;
        using (Bitmap bmp = new Bitmap(Width, Height, PixelFormat.Format32bppArgb))
        {
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = TextRenderingHint.AntiAlias;
                g.Clear(Color.Transparent);

                PointF c = new PointF(Width / 2f, Height / 2f);
                // Everything is drawn in lens units; pressing shrinks the lens slightly.
                float u = scale * (pressed && !dragging ? 0.95f : 1f);
                float glow = flashOk ? flash : 0f;

                // Flashbulb halo after a successful capture.
                if (glow > 0.01f)
                    using (GraphicsPath hp = new GraphicsPath())
                    {
                        hp.AddEllipse(0, 0, Width, Height);
                        using (PathGradientBrush pb = new PathGradientBrush(hp))
                        {
                            pb.CenterColor = Color.FromArgb((int)(200 * glow), 255, 250, 225);
                            pb.SurroundColors = new Color[] { Color.FromArgb(0, 255, 250, 225) };
                            g.FillPath(pb, hp);
                        }
                    }

                // Soft drop shadow.
                RectangleF sr = Circle(c, LensR * scale + pad * 0.7f);
                sr.Offset(0, 3 * scale);
                using (GraphicsPath sp = new GraphicsPath())
                {
                    sp.AddEllipse(sr);
                    using (PathGradientBrush pb = new PathGradientBrush(sp))
                    {
                        pb.CenterColor = Color.FromArgb(dragging ? 160 : 120, 0, 0, 0);
                        pb.SurroundColors = new Color[] { Color.FromArgb(0, 0, 0, 0) };
                        pb.FocusScales = new PointF(0.6f, 0.6f);
                        g.FillPath(pb, sp);
                    }
                }

                DrawLens(g, c, u, glow);

                // Result badge: green check or red error.
                if (flash > 0.01f)
                {
                    int a = (int)(255 * Math.Min(1f, flash * 1.6f));
                    RectangleF br = Circle(new PointF(c.X + 21 * scale, c.Y - 21 * scale), 8.5f * scale);
                    using (SolidBrush bb = new SolidBrush(Color.FromArgb(a, flashOk ? OkColor : FailColor))) g.FillEllipse(bb, br);
                    using (Pen bw = new Pen(Color.FromArgb(a, 255, 255, 255), 1.5f * scale)) g.DrawEllipse(bw, br);
                    using (Font f = new Font(iconFont, 8.5f * scale, GraphicsUnit.Pixel))
                    using (SolidBrush fb = new SolidBrush(Color.FromArgb(a, 255, 255, 255)))
                    using (StringFormat sf = Centered())
                        g.DrawString(flashOk ? CheckGlyph : ErrorGlyph, f, fb, br, sf);
                }
            }
            byte alpha = hidden ? (byte)0 : (byte)(232 + 23 * Math.Max(hover, Math.Max(flash, pressed ? 1f : 0f)));
            SetBitmap(bmp, alpha);
        }
    }

    void DrawLens(Graphics g, PointF c, float u, float glow)
    {
        // Brushed-aluminium bezel: chrome sheen plus fine concentric grain.
        RectangleF bezel = Circle(c, LensR * u);
        using (LinearGradientBrush b = ChromeBrush(bezel, 45f, hover)) g.FillEllipse(b, bezel);
        Random grain = new Random(11);
        for (float r = 24f; r < LensR; r += 0.35f)
            using (Pen p = new Pen(grain.Next(2) == 0
                ? Color.FromArgb(grain.Next(10, 34), 255, 255, 255)
                : Color.FromArgb(grain.Next(8, 26), 0, 0, 0), 0.5f * u))
                g.DrawEllipse(p, Circle(c, r * u));
        using (Pen edge = new Pen(Color.FromArgb(150, 40, 40, 44), 1f * u)) g.DrawEllipse(edge, Grow(bezel, -0.5f * u));

        // Recessed bevel into a dark barrel (lit from below, so it reads as sunken).
        RectangleF bevel = Circle(c, 24f * u);
        using (LinearGradientBrush b = new LinearGradientBrush(Grow(bevel, 1f), Color.FromArgb(12, 12, 14), Color.FromArgb(110, 110, 118), 90f))
            g.FillEllipse(b, bevel);
        RectangleF barrel = Circle(c, 22.5f * u);
        using (LinearGradientBrush b = new LinearGradientBrush(Grow(barrel, 1f), Color.FromArgb(34, 34, 40), Color.FromArgb(6, 6, 8), 90f))
            g.FillEllipse(b, barrel);
        using (Pen sheen = new Pen(Color.FromArgb(32, 255, 255, 255), 1f * u))
            g.DrawArc(sheen, Circle(c, 20.3f * u), 200, 140);

        // Thin, dimmed chrome retaining ring, then a black seat for the glass.
        RectangleF ring = Circle(c, 17.3f * u);
        using (LinearGradientBrush b = ChromeBrush(ring, 270f, 0f)) g.FillEllipse(b, ring);
        using (SolidBrush dim = new SolidBrush(Color.FromArgb(90, 0, 0, 0))) g.FillEllipse(dim, ring);
        RectangleF seat = Circle(c, 16.5f * u);
        using (SolidBrush b = new SolidBrush(Color.FromArgb(10, 10, 12))) g.FillEllipse(b, seat);

        // Coated glass, deep blue-violet; blazes white with the flash.
        RectangleF glass = Circle(c, 15f * u);
        using (GraphicsPath gp = new GraphicsPath())
        {
            gp.AddEllipse(glass);
            using (PathGradientBrush pb = new PathGradientBrush(gp))
            {
                pb.CenterPoint = new PointF(c.X - 3 * u, c.Y - 3 * u);
                pb.CenterColor = Lerp(Color.FromArgb(70, 58, 150), Color.White, glow * 0.9f);
                pb.SurroundColors = new Color[] { Lerp(Color.FromArgb(4, 6, 18), Color.FromArgb(225, 225, 235), glow * 0.9f) };
                g.FillEllipse(pb, glass);
            }
        }

        // Inner lens elements and coating reflections.
        using (Pen el = new Pen(Color.FromArgb(70, 120, 110, 220), 0.8f * u)) g.DrawEllipse(el, Circle(c, 9f * u));
        using (SolidBrush core = new SolidBrush(Color.FromArgb(120, 2, 2, 10))) g.FillEllipse(core, Circle(c, 5f * u));

        // Faint shortcut hint in the middle of the glass; a little clearer on hover, gone during the flash.
        int ha = (int)((70 + 80 * hover) * (1f - glow));
        if (hotkeyOk && ha > 2)
            using (Font f = new Font("Segoe UI Semibold", 5f * u, GraphicsUnit.Pixel))
            using (SolidBrush hb = new SolidBrush(Color.FromArgb(ha, 220, 220, 255)))
            using (StringFormat sf = Centered())
                g.DrawString("ALT+C", f, hb, Circle(c, 10f * u), sf);
        using (Pen coat = new Pen(Color.FromArgb(55, 90, 220, 160), 2.4f * u)) g.DrawArc(coat, Circle(c, 12f * u), 10, 80);
        using (Pen coat = new Pen(Color.FromArgb(50, 235, 130, 220), 1.8f * u)) g.DrawArc(coat, Circle(c, 7f * u), 195, 60);
        using (Pen coat = new Pen(Color.FromArgb(45, 250, 200, 90), 1.4f * u)) g.DrawArc(coat, Circle(c, 10.5f * u), 120, 35);

        // Glints: a soft crescent top-left and a pinpoint bottom-right; brighter on hover.
        int ga = (int)(150 + 95 * hover);
        GraphicsState st = g.Save();
        g.TranslateTransform(c.X - 5.5f * u, c.Y - 7.5f * u);
        g.RotateTransform(-35);
        RectangleF glint = new RectangleF(-7 * u, -3 * u, 14 * u, 6 * u);
        using (LinearGradientBrush gb = new LinearGradientBrush(Grow(glint, 1f), Color.FromArgb(ga, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
            g.FillEllipse(gb, glint);
        g.Restore(st);
        using (SolidBrush dot = new SolidBrush(Color.FromArgb((int)(ga * 0.8f), 255, 255, 255)))
            g.FillEllipse(dot, c.X + 5.5f * u, c.Y + 5f * u, 2.4f * u, 2.4f * u);
        using (Pen rim = new Pen(Color.FromArgb(230, 0, 0, 0), 1f * u)) g.DrawEllipse(rim, glass);
    }

    static LinearGradientBrush ChromeBrush(RectangleF r, float angle, float lift)
    {
        LinearGradientBrush b = new LinearGradientBrush(Grow(r, 1f), Color.White, Color.Black, angle);
        ColorBlend blend = new ColorBlend();
        Color dark = Lerp(Color.FromArgb(150, 150, 156), Color.FromArgb(172, 172, 178), lift);
        blend.Colors = new Color[] {
            Color.FromArgb(248, 248, 250), Lerp(Color.FromArgb(186, 186, 192), Color.FromArgb(206, 206, 212), lift),
            Color.FromArgb(236, 236, 240), dark, Color.FromArgb(205, 205, 210) };
        blend.Positions = new float[] { 0f, 0.38f, 0.58f, 0.85f, 1f };
        b.InterpolationColors = blend;
        return b;
    }

    static StringFormat Centered()
    {
        StringFormat sf = new StringFormat();
        sf.Alignment = StringAlignment.Center;
        sf.LineAlignment = StringAlignment.Center;
        return sf;
    }

    void SetBitmap(Bitmap bmp, byte alpha)
    {
        IntPtr screenDc = GetDC(IntPtr.Zero);
        IntPtr memDc = CreateCompatibleDC(screenDc);
        IntPtr hBmp = bmp.GetHbitmap(Color.FromArgb(0));
        IntPtr old = SelectObject(memDc, hBmp);
        try
        {
            SIZE size = new SIZE(bmp.Width, bmp.Height);
            POINT src = new POINT(0, 0);
            POINT dst = new POINT(Left, Top);
            BLENDFUNCTION bf = new BLENDFUNCTION();
            bf.Alpha = alpha;
            bf.Format = 1; // AC_SRC_ALPHA: per-pixel transparency for smooth edges
            UpdateLayeredWindow(Handle, screenDc, ref dst, ref size, memDc, ref src, 0, ref bf, 2);
        }
        finally
        {
            SelectObject(memDc, old);
            DeleteObject(hBmp);
            DeleteDC(memDc);
            ReleaseDC(IntPtr.Zero, screenDc);
        }
    }

    static RectangleF Circle(PointF c, float r) { return new RectangleF(c.X - r, c.Y - r, r * 2, r * 2); }

    static RectangleF Grow(RectangleF r, float by) { r.Inflate(by, by); return r; }

    static Color Lerp(Color a, Color b, float t)
    {
        t = Math.Max(0f, Math.Min(1f, t));
        return Color.FromArgb(
            (int)(a.A + (b.A - a.A) * t), (int)(a.R + (b.R - a.R) * t),
            (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
    }
}
"@

[SnapButton]::Run()
$mutex.ReleaseMutex()
