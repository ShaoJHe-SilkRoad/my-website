# ALT+C Screenshot Wizard

A tiny floating lens button for Windows that copies a screenshot of the entire screen to the clipboard.

Version 0.1.0

## Use

- **Click the lens** or press **Alt+C** anywhere: every monitor is captured and the image goes on the clipboard. Paste with `Ctrl+V`.
- **Drag** the lens to move it.
- **Right-click** for the menu (Take screenshot / Exit).

The lens hides itself during the capture so it never appears in your screenshots. It flashes white with a green check when the image is on the clipboard (red if the capture failed). Clicking it does not take focus away from the app you were using.

## Run

Double-click `ScreenSnap.vbs`. It starts `ScreenSnap.ps1` without a console window.

If VBScript is blocked on your machine, run this instead:

```
powershell -NoProfile -STA -WindowStyle Hidden -File "path\to\ScreenSnap.ps1"
```

To start it automatically at sign-in, press `Win+R`, type `shell:startup`, and put a shortcut to `ScreenSnap.vbs` in that folder.

## Requirements

Windows 10 or 11 with the built-in Windows PowerShell 5.1. Nothing to install.

## Notes

- While it is running, Alt+C belongs to ScreenSnap in every app. If another app already holds Alt+C, clicking still works and the shortcut hint on the lens is hidden.
- Only one copy runs at a time.
- High-DPI displays (125%, 150%, ...) are captured at full resolution.
